from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    BOT_TOKEN: str
    ADMIN_PASSWORD: str = "admin2026"
    ADMIN_IDS: list[int] = []
    DB_PATH: str = "osint_bot.db"

    FREE_WEEKLY_LIMIT: int = 5
    HISTORY_RETENTION_DAYS: int = 7
    TG_MSG_CHAR_LIMIT: int = 4000

    PRICE_SINGLE_DEEP_XTR: int = 150
    PRICE_WEEK_XTR: int = 450
    PRICE_MONTH_XTR: int = 1000
    PRICE_QUARTER_XTR: int = 2500

    VK_SERVICE_TOKEN: str = ""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


settings = Settings()

TARIFFS = {
    "single_deep": {
        "title": "🚀 Разовый DEEP-поиск (1 шт.)",
        "days": 0,
        "deep_credits": 1,
        "price": settings.PRICE_SINGLE_DEEP_XTR,
    },
    "prem_7": {
        "title": "💎 Premium на 7 дней (Безлимит)",
        "days": 7,
        "deep_credits": 0,
        "price": settings.PRICE_WEEK_XTR,
    },
    "prem_30": {
        "title": "👑 Premium на 30 дней (Безлимит)",
        "days": 30,
        "deep_credits": 0,
        "price": settings.PRICE_MONTH_XTR,
    },
    "prem_90": {
        "title": "🔥 VIP Premium на 90 дней (Безлимит)",
        "days": 90,
        "deep_credits": 0,
        "price": settings.PRICE_QUARTER_XTR,
    },
}
