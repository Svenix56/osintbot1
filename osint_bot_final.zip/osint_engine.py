import asyncio
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone
from io import BytesIO
from urllib.parse import quote_plus

import aiohttp
import dns.resolver
import exifread
import phonenumbers
from bs4 import BeautifulSoup
from phonenumbers import carrier, geocoder, timezone as pn_timezone

from config import settings
from database import is_target_blocked
from validators import TargetType

# Регулярные выражения для вытаскивания зацепок из текста, коммитов и дампов
EXTRACT_PHONE_RE = re.compile(r"(?:\+7|8)[\s\-\(]*9\d{2}[\s\-\)]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2}")
EXTRACT_EMAIL_RE = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,6}")
EXTRACT_IP_RE = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b")


async def run_cli(args: list[str], timeout: int = 60) -> str:
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        out = stdout.decode("utf-8", errors="ignore").strip()
        return out if out else "Совпадений не найдено."
    except FileNotFoundError:
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", *args,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            out = stdout.decode("utf-8", errors="ignore").strip()
            return out if out else "Совпадений не найдено."
        except Exception:
            return f"Утилита {args[0]} не установлена."
    except asyncio.TimeoutError:
        return f"Таймаут ({timeout} с)."
    except Exception as e:
        return f"Ошибка {args[0]}: {e}"


class OSINTEngine:
    def __init__(self):
        self.timeout = aiohttp.ClientTimeout(total=25)
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7"
        }

    # ==================== 1. CLI ФРЕЙМВОРКИ ====================

    async def run_maigret(self, username: str, full: bool = False) -> str:
        sites = "350" if full else "60"
        t_out = 160 if full else 45
        return await run_cli(["maigret", username, "--top-sites", sites, "--no-color", "--timeout", "8"], timeout=t_out)

    async def run_holehe(self, email: str) -> str:
        return await run_cli(["holehe", email, "--only-used", "--no-color"], timeout=45)

    async def run_ignorant(self, phone: str) -> str:
        clean_digits = re.sub(r"\D", "", phone)
        if clean_digits.startswith("7") and len(clean_digits) == 11:
            return await run_cli(["ignorant", "7", clean_digits[1:], "--only-used", "--no-color"], timeout=40)
        return "Не найдено"

    # ==================== 2. НОВЫЕ API ПО НИКНЕЙМУ (STEAM, GITHUB, GITLAB, KEYBASE, REDDIT, CHESS, HABR, PIKABU) ====================

    async def extended_social_apis(self, username: str, session: aiohttp.ClientSession) -> dict:
        """Опрашивает 10 открытых бесключевых API для вытаскивания реального ФИО, почты, геолокации и аккаунтов."""
        results = {}
        found_names = []
        found_emails = []
        found_locations = []
        found_profiles = []

        # 1. Steam XML API (без ключа отдаёт реальное имя, город и дату регистрации)
        try:
            async with session.get(f"https://steamcommunity.com/id/{username}?xml=1", headers=self.headers) as r:
                if r.status == 200:
                    xml_txt = await r.text()
                    if "<steamID64>" in xml_txt:
                        soup = BeautifulSoup(xml_txt, "html.parser")
                        sid = soup.find("steamid64").get_text(strip=True) if soup.find("steamid64") else ""
                        rname = soup.find("realname").get_text(strip=True) if soup.find("realname") else ""
                        loc = soup.find("location").get_text(strip=True) if soup.find("location") else ""
                        since = soup.find("membersince").get_text(strip=True) if soup.find("membersince") else ""
                        results["steam"] = {"steamID64": sid, "realname": rname, "location": loc, "member_since": since}
                        found_profiles.append(f"Steam ({rname or username})")
                        if rname:
                            found_names.append(f"{rname} (Steam)")
                        if loc:
                            found_locations.append(f"{loc} (Steam)")
        except Exception:
            pass

        # 2. GitHub User + Events API (достаёт ФИО, блог и Email из пушей без токена)
        try:
            async with session.get(f"https://api.github.com/users/{username}", headers=self.headers) as r:
                if r.status == 200:
                    gh = await r.json()
                    results["github_profile"] = {
                        "name": gh.get("name"),
                        "company": gh.get("company"),
                        "blog": gh.get("blog"),
                        "location": gh.get("location"),
                        "email": gh.get("email"),
                        "bio": gh.get("bio"),
                        "twitter": gh.get("twitter_username"),
                        "created_at": gh.get("created_at", "")[:10]
                    }
                    found_profiles.append("GitHub")
                    if gh.get("name"):
                        found_names.append(f"{gh['name']} (GitHub)")
                    if gh.get("location"):
                        found_locations.append(f"{gh['location']} (GitHub)")
                    if gh.get("email"):
                        found_emails.append(gh["email"])

            async with session.get(f"https://api.github.com/users/{username}/events/public", headers=self.headers) as r2:
                if r2.status == 200:
                    events = await r2.json()
                    for ev in events[:15]:
                        for c in ev.get("payload", {}).get("commits", []):
                            em = c.get("author", {}).get("email", "")
                            nm = c.get("author", {}).get("name", "")
                            if em and "noreply" not in em and em not in found_emails:
                                found_emails.append(em)
                            if nm and nm not in found_names and len(nm) > 2:
                                found_names.append(f"{nm} (Git Commit)")
        except Exception:
            pass

        # 3. GitLab Public API
        try:
            async with session.get(f"https://gitlab.com/api/v4/users?username={username}", headers=self.headers) as r:
                if r.status == 200:
                    gl_list = await r.json()
                    if gl_list:
                        gl = gl_list[0]
                        results["gitlab"] = {"id": gl.get("id"), "name": gl.get("name"), "url": gl.get("web_url")}
                        found_profiles.append("GitLab")
                        if gl.get("name"):
                            found_names.append(f"{gl['name']} (GitLab)")
        except Exception:
            pass

        # 4. Keybase Crypto Lookup API (связанные соцсети, домены и устройства)
        try:
            async with session.get(f"https://keybase.io/_/api/1.0/user/lookup.json?usernames={username}", headers=self.headers) as r:
                if r.status == 200:
                    kb_data = (await r.json()).get("them", [])
                    if kb_data and kb_data[0]:
                        kb = kb_data[0]
                        prof = kb.get("profile", {})
                        proofs = [
                            f"{p.get('proof_type')}: {p.get('nametag')}"
                            for p in kb.get("proofs_summary", {}).get("all", [])
                        ]
                        results["keybase"] = {
                            "full_name": prof.get("full_name"),
                            "location": prof.get("location"),
                            "bio": prof.get("bio"),
                            "verified_accounts": proofs
                        }
                        found_profiles.append("Keybase")
                        if prof.get("full_name"):
                            found_names.append(f"{prof['full_name']} (Keybase)")
                        if prof.get("location"):
                            found_locations.append(f"{prof['location']} (Keybase)")
        except Exception:
            pass

        # 5. Reddit JSON API
        try:
            async with session.get(f"https://www.reddit.com/user/{username}/about.json", headers=self.headers) as r:
                if r.status == 200:
                    rd = (await r.json()).get("data", {})
                    if rd.get("created_utc"):
                        created = datetime.fromtimestamp(rd["created_utc"], tz=timezone.utc).strftime("%Y-%m-%d")
                        results["reddit"] = {
                            "name": rd.get("name"),
                            "title": rd.get("subreddit", {}).get("title"),
                            "bio": rd.get("subreddit", {}).get("public_description"),
                            "total_karma": rd.get("total_karma"),
                            "created_at": created
                        }
                        found_profiles.append(f"Reddit (c {created})")
        except Exception:
            pass

        # 6. Chess.com Public API
        try:
            async with session.get(f"https://api.chess.com/pub/player/{username}", headers=self.headers) as r:
                if r.status == 200:
                    ch = await r.json()
                    results["chess_com"] = {
                        "name": ch.get("name"),
                        "location": ch.get("location"),
                        "url": ch.get("url")
                    }
                    found_profiles.append("Chess.com")
                    if ch.get("name"):
                        found_names.append(f"{ch['name']} (Chess.com)")
                    if ch.get("location"):
                        found_locations.append(f"{ch['location']} (Chess.com)")
        except Exception:
            pass

        # 7. Habr & Pikabu (парсинг русскоязычных площадок)
        for site_name, url in [("Habr", f"https://habr.com/ru/users/{username}/"), ("Pikabu", f"https://pikabu.ru/@{username}")]:
            try:
                async with session.get(url, headers=self.headers) as r:
                    if r.status == 200:
                        soup = BeautifulSoup(await r.text(), "html.parser")
                        t = soup.find("title")
                        if t and "404" not in t.text:
                            results[site_name.lower()] = {"url": url, "title": t.get_text(strip=True)[:100]}
                            found_profiles.append(site_name)
            except Exception:
                pass

        results["_summary"] = {
            "names": found_names,
            "emails": found_emails,
            "locations": found_locations,
            "profiles": found_profiles
        }
        return results

    async def tiktok_youtube_lookup(self, username: str, session: aiohttp.ClientSession) -> dict:
        res = {"tiktok": "Не найден", "youtube": "Не найден"}

        tt_url = f"https://www.tiktok.com/@{username}"
        try:
            async with session.get(tt_url, headers=self.headers) as r:
                if r.status == 200:
                    html = await r.text()
                    soup = BeautifulSoup(html, "html.parser")
                    title_el = soup.find("title")
                    title_txt = title_el.get_text(strip=True) if title_el else ""
                    if title_txt and "TikTok" in title_txt and f"@{username.lower()}" in html.lower():
                        clean_t = title_txt.replace("| TikTok", "").strip()
                        res["tiktok"] = f"{clean_t} ({tt_url})"
        except Exception:
            pass

        yt_url = f"https://www.youtube.com/@{username}"
        try:
            async with session.get(yt_url, headers=self.headers) as r:
                if r.status == 200:
                    html = await r.text()
                    soup = BeautifulSoup(html, "html.parser")
                    og_title = soup.find("meta", property="og:title")
                    if og_title and og_title.has_attr("content"):
                        res["youtube"] = f"{og_title['content']} ({yt_url})"
        except Exception:
            pass

        return res

    # ==================== 3. ДОПОЛНИТЕЛЬНЫЕ ИНСТРУМЕНТЫ ПО ПОЧТЕ (DUOLINGO, PGP, MX) ====================

    async def email_extra_osint(self, email: str, session: aiohttp.ClientSession) -> dict:
        extra = {"duolingo": None, "pgp_uid": None, "mail_server": None}

        # 1. Duolingo Public API (по Email часто отдаёт реальное Имя и Username!)
        try:
            duo_url = f"https://www.duolingo.com/2017-06-30/users?email={quote_plus(email)}"
            async with session.get(duo_url, headers=self.headers) as r:
                if r.status == 200:
                    users = (await r.json()).get("users", [])
                    if users:
                        u = users[0]
                        extra["duolingo"] = {
                            "username": u.get("username"),
                            "name": u.get("name"),
                            "streak": u.get("streak")
                        }
        except Exception:
            pass

        # 2. Ubuntu PGP Keyserver (вытаскивает ФИО владельца ключа)
        try:
            pgp_url = f"https://keyserver.ubuntu.com/pks/lookup?search={quote_plus(email)}&op=index&options=mr"
            async with session.get(pgp_url, headers=self.headers) as r:
                if r.status == 200:
                    txt = await r.text()
                    for line in txt.splitlines():
                        if line.startswith("uid:"):
                            uid_str = line.split(":")[1]
                            extra["pgp_uid"] = uid_str
                            break
        except Exception:
            pass

        # 3. MX записи почтового домена
        domain = email.split("@")[-1]
        dns_res = self.dns_and_ip_resolve(domain)
        if dns_res.get("MX"):
            extra["mail_server"] = dns_res["MX"][:2]

        return extra

    # ==================== 4. ДОПОЛНИТЕЛЬНЫЕ ИНСТРУМЕНТЫ ПО ТЕЛЕФОНУ (HTMLWEB MNP, LEAKCHECK, DORKS) ====================

    async def phone_extra_osint(self, phone: str, session: aiohttp.ClientSession) -> dict:
        digits = re.sub(r"\D", "", phone)
        info = {
            "messengers": {
                "whatsapp": f"https://wa.me/{digits}",
                "telegram": f"https://t.me/+{digits}",
                "viber": f"viber://chat?number={digits}"
            },
            "htmlweb_mnp": {},
            "leakcheck_phone": "Утечек по номеру не найдено",
            "web_mentions": []
        }

        # 1. HtmlWeb Free Geo/MNP API (точный оператор, город и регион)
        try:
            hw_url = f"https://htmlweb.ru/geo/api.php?json&telcod={digits}"
            async with session.get(hw_url, headers=self.headers) as r:
                if r.status == 200:
                    data = await r.json()
                    info["htmlweb_mnp"] = {
                        "country": data.get("country", {}).get("name"),
                        "region": data.get("region", {}).get("name"),
                        "city": data.get("0", {}).get("name"),
                        "operator": data.get("0", {}).get("oper"),
                        "operator_brand": data.get("0", {}).get("oper_brand")
                    }
        except Exception:
            pass

        # 2. LeakCheck Public API по номеру телефона
        try:
            async with session.get(f"https://leakcheck.io/api/public?check={digits}", headers=self.headers) as r:
                if r.status == 200:
                    lc = await r.json()
                    if lc.get("success") and lc.get("found", 0) > 0:
                        dbs = [f"{s.get('name')} ({s.get('date') or 'н/д'})" for s in lc.get("sources", [])]
                        info["leakcheck_phone"] = f"Найдено в базах ({lc['found']}): {', '.join(dbs[:6])}"
        except Exception:
            pass

        # 3. Веб-поиск упоминаний номера (объявления, справочники, резюме)
        try:
            short_10_digits = digits[-10:] if len(digits) >= 10 else digits
            q = f'"{digits}" OR "{short_10_digits}"'
            async with session.post("https://html.duckduckgo.com/html/", data={"q": q}, headers=self.headers) as r:
                if r.status == 200:
                    soup = BeautifulSoup(await r.text(), "html.parser")
                    for res_block in soup.select(".result__body")[:5]:
                        title_el = res_block.select_one("a.result__a")
                        snip_el = res_block.select_one(".result__snippet")
                        if title_el:
                            info["web_mentions"].append({
                                "title": title_el.get_text(strip=True)[:80],
                                "snippet": snip_el.get_text(strip=True)[:140] if snip_el else "",
                                "url": title_el.get("href", "")
                            })
        except Exception:
            pass

        return info

    # ==================== 5. SHODAN INTERNETDB & IP-API (БЕЗ КЛЮЧЕЙ!) ====================

    async def ip_deep_intelligence(self, ip: str, session: aiohttp.ClientSession) -> dict:
        res = {"geo": {}, "shodan_internetdb": {}, "flags": []}

        # 1. ip-api.com (с проверкой на Proxy / VPN / Hosting / Mobile)
        try:
            url = f"http://ip-api.com/json/{ip}?fields=status,country,regionName,city,isp,org,as,reverse,mobile,proxy,hosting&lang=ru"
            async with session.get(url) as r:
                if r.status == 200:
                    d = await r.json()
                    res["geo"] = d
                    if d.get("mobile"):
                        res["flags"].append("📱 Мобильная сеть")
                    if d.get("proxy"):
                        res["flags"].append("🛡 VPN / Proxy / Tor")
                    if d.get("hosting"):
                        res["flags"].append("🖥 Хостинг / Дата-центр")
        except Exception:
            pass

        # 2. Shodan InternetDB (открытые порты, сервисы, теги, уязвимости CVE)
        try:
            async with session.get(f"https://internetdb.shodan.io/{ip}", headers=self.headers) as r:
                if r.status == 200:
                    res["shodan_internetdb"] = await r.json()
        except Exception:
            pass

        return res

    # ==================== 6. ПОИСК ТЕЛЕФОНА, ПОЧТЫ И IP ПО НИКУ ====================

    async def extract_contacts_and_ip_by_nick(
        self, username: str, vk_prof: dict, tg_prof: dict, breaches: dict, ext_soc: dict, session: aiohttp.ClientSession
    ) -> dict:
        found_phones = set()
        found_emails = set(ext_soc.get("_summary", {}).get("emails", []))
        found_ips = set()

        if isinstance(vk_prof, dict):
            if vk_prof.get("mobile_phone"):
                found_phones.add(vk_prof["mobile_phone"])
            if vk_prof.get("home_phone"):
                found_phones.add(vk_prof["home_phone"])
            site = vk_prof.get("site", "")
            if site:
                clean_dom = re.sub(r"^https?://", "", site).split("/")[0].strip()
                for ip in self.dns_and_ip_resolve(clean_dom).get("A", []):
                    found_ips.add(f"{ip} (сайт {clean_dom})")

        gh_blog = ext_soc.get("github_profile", {}).get("blog")
        if gh_blog:
            clean_dom = re.sub(r"^https?://", "", gh_blog).split("/")[0].strip()
            for ip in self.dns_and_ip_resolve(clean_dom).get("A", []):
                found_ips.add(f"{ip} (GitHub-сайт {clean_dom})")

        for s in breaches.get("stealers_raw", []):
            ip_val = s.get("ip")
            comp_name = s.get("computer_name")
            if ip_val and ip_val.lower() != "not found":
                found_ips.add(f"{ip_val} (ПК: {comp_name or 'н/д'})")

        for c in breaches.get("commits", []):
            for em in EXTRACT_EMAIL_RE.findall(c):
                if "noreply" not in em:
                    found_emails.add(em)

        combined_bio = f"{tg_prof.get('bio', '')} {vk_prof.get('status', '') if isinstance(vk_prof, dict) else ''}"
        for ph in EXTRACT_PHONE_RE.findall(combined_bio):
            found_phones.add(ph.strip())
        for em in EXTRACT_EMAIL_RE.findall(combined_bio):
            found_emails.add(em.strip())

        try:
            ddg_url = "https://html.duckduckgo.com/html/"
            async with session.post(ddg_url, data={"q": f'"{username}" ("+79" OR "@gmail.com" OR "@mail.ru" OR "@yandex.ru" OR "тел")'}, headers=self.headers) as r:
                if r.status == 200:
                    text_page = BeautifulSoup(await r.text(), "html.parser").get_text(" ")
                    for ph in EXTRACT_PHONE_RE.findall(text_page):
                        found_phones.add(ph.strip())
                    for em in EXTRACT_EMAIL_RE.findall(text_page):
                        found_emails.add(em.strip())
        except Exception:
            pass

        local_lines = await self.search_local_dumps(username)
        for line in local_lines:
            for ph in EXTRACT_PHONE_RE.findall(line):
                found_phones.add(ph.strip())
            for em in EXTRACT_EMAIL_RE.findall(line):
                found_emails.add(em.strip())
            for ip in EXTRACT_IP_RE.findall(line):
                found_ips.add(f"{ip} (локальная БД)")

        return {
            "phones": sorted(list(found_phones))[:5],
            "emails": sorted(list(found_emails))[:5],
            "ips": sorted(list(found_ips))[:5]
        }

    # ==================== 7. АНАЛИЗ СЛИТЫХ БАЗ И УТЕЧЕК ====================

    async def deep_breach_intelligence(self, target: str, target_type: TargetType, session: aiohttp.ClientSession) -> dict:
        intel = {"databases": [], "fields": [], "stealers": "Чисто", "stealers_raw": [], "commits": [], "xposed_details": []}

        if target_type in (TargetType.EMAIL, TargetType.USERNAME):
            try:
                async with session.get(f"https://leakcheck.io/api/public?check={target}", headers=self.headers) as r:
                    if r.status == 200:
                        data = await r.json()
                        if data.get("success") and data.get("found", 0) > 0:
                            intel["fields"] = data.get("fields", [])
                            intel["databases"] = [
                                f"{s.get('name')} ({s.get('date') or 'н/д'})"
                                for s in data.get("sources", [])
                            ]
            except Exception:
                pass

        if target_type == TargetType.EMAIL:
            try:
                async with session.get(f"https://api.xposedornot.com/v1/breach-analytics?email={target}", headers=self.headers) as r:
                    if r.status == 200:
                        data = await r.json()
                        details = data.get("ExposedBreaches", {}).get("breaches_details", [])
                        for b in details[:12]:
                            b_name = f"{b.get('breach')} ({b.get('xposed_date')})"
                            if b_name not in intel["databases"]:
                                intel["databases"].append(b_name)
                            intel["xposed_details"].append({
                                "db": b.get("breach"),
                                "year": b.get("xposed_date"),
                                "data": b.get("xposed_data")
                            })
            except Exception:
                pass

        if target_type in (TargetType.EMAIL, TargetType.USERNAME, TargetType.DOMAIN):
            ep_map = {
                TargetType.EMAIL: f"search-by-email?email={target}",
                TargetType.USERNAME: f"search-by-username?username={target}",
                TargetType.DOMAIN: f"search-by-domain?domain={target}"
            }
            try:
                url = f"https://cavalier.hudsonrock.com/api/json/v2/osint-tools/{ep_map[target_type]}"
                async with session.get(url, headers=self.headers) as r:
                    if r.status == 200:
                        data = await r.json()
                        stealers = data.get("stealers", [])
                        if stealers:
                            intel["stealers_raw"] = stealers[:5]
                            ips_in_stealer = [s.get("ip") for s in stealers if s.get("ip")]
                            comps = [s.get("computer_name") for s in stealers if s.get("computer_name")]
                            extra_s = f" | IP: {', '.join(ips_in_stealer[:2])} | ПК: {', '.join(comps[:2])}" if (ips_in_stealer or comps) else ""
                            intel["stealers"] = f"Записей в логах стилеров: {len(stealers)}{extra_s}"
            except Exception:
                pass

        if target_type in (TargetType.EMAIL, TargetType.USERNAME):
            try:
                gh_headers = {**self.headers, "Accept": "application/vnd.github.cloak-preview+json"}
                q = f"author-email:{target}" if target_type == TargetType.EMAIL else f"author:{target}"
                async with session.get(f"https://api.github.com/search/commits?q={q}&per_page=5", headers=gh_headers) as r:
                    if r.status == 200:
                        for item in (await r.json()).get("items", []):
                            a = item.get("commit", {}).get("author", {})
                            repo = item.get("repository", {}).get("full_name")
                            entry = f"{a.get('name')} <{a.get('email')}> ({repo})"
                            if entry not in intel["commits"]:
                                intel["commits"].append(entry)
            except Exception:
                pass

        return intel

    # ==================== 8. ВК, ОДНОКЛАССНИКИ, ИП/ООО И TELEGRAM ====================

    async def vk_lookup(self, query: str, session: aiohttp.ClientSession, by_name: bool = False) -> dict | list:
        if settings.VK_SERVICE_TOKEN:
            if by_name:
                url = "https://api.vk.com/method/users.search"
                params = {"q": query, "count": 5, "fields": "bdate,city,domain,contacts,site", "access_token": settings.VK_SERVICE_TOKEN, "v": "5.199", "lang": "ru"}
                async with session.get(url, params=params) as r:
                    items = (await r.json()).get("response", {}).get("items", [])
                    if items:
                        return [
                            {
                                "id": u.get("id"),
                                "full_name": f"{u.get('first_name')} {u.get('last_name')}",
                                "city": u.get("city", {}).get("title"),
                                "bdate": u.get("bdate"),
                                "mobile_phone": u.get("mobile_phone"),
                                "url": f"https://vk.com/{u.get('domain')}"
                            }
                            for u in items
                        ]
            else:
                url = "https://api.vk.com/method/users.get"
                params = {"user_ids": query, "fields": "first_name,last_name,bdate,city,domain,status,contacts,site", "access_token": settings.VK_SERVICE_TOKEN, "v": "5.199", "lang": "ru"}
                async with session.get(url, params=params) as r:
                    users = (await r.json()).get("response", [])
                    if users:
                        u = users[0]
                        return {
                            "found": True,
                            "vk_id": u.get("id"),
                            "full_name": f"{u.get('first_name', '')} {u.get('last_name', '')}".strip(),
                            "url": f"https://vk.com/{u.get('domain')}",
                            "bdate": u.get("bdate", "Скрыта"),
                            "city": u.get("city", {}).get("title", "Скрыт"),
                            "status": u.get("status", ""),
                            "mobile_phone": u.get("mobile_phone", ""),
                            "home_phone": u.get("home_phone", ""),
                            "site": u.get("site", "")
                        }

        if by_name:
            ddg_url = "https://html.duckduckgo.com/html/"
            results = []
            try:
                async with session.post(ddg_url, data={"q": f'(site:vk.com OR site:ok.ru OR site:rusprofile.ru) "{query}"'}, headers=self.headers) as r:
                    if r.status == 200:
                        soup = BeautifulSoup(await r.text(), "html.parser")
                        for a in soup.select("a.result__a")[:7]:
                            title_txt = a.get_text(strip=True)
                            href = a.get("href", "")
                            if not any(x in href for x in ("wall", "video", "clip", "login")):
                                results.append({
                                    "full_name": title_txt.split("|")[0].strip()[:80],
                                    "city": "Открытый реестр / Соцсеть",
                                    "bdate": "см. источник",
                                    "url": href
                                })
            except Exception:
                pass
            return results

        target_slug = f"id{query}" if query.isdigit() else query
        url = f"https://vk.com/{target_slug}"
        try:
            async with session.get(url, headers=self.headers) as r:
                if r.status == 200:
                    html_text = await r.text()
                    soup = BeautifulSoup(html_text, "html.parser")
                    title = soup.find("title")
                    og_title = soup.find("meta", property="og:title")
                    socid_data = {}
                    try:
                        from socid_extractor import extract
                        socid_data = extract(html_text) or {}
                    except Exception:
                        pass

                    if title and ("ВКонтакте" in title.text or "VK" in title.text) and "404" not in title.text:
                        name = (
                            socid_data.get("fullname")
                            or (og_title["content"] if (og_title and og_title.has_attr("content")) else "")
                            or title.text.split("|")[0].strip()
                        )
                        return {
                            "found": True,
                            "vk_id": socid_data.get("uid", target_slug),
                            "full_name": name,
                            "url": url,
                            "city": socid_data.get("city", ""),
                            "bdate": socid_data.get("birthday", "Скрыта")
                        }
        except Exception:
            pass
        return {"found": False}

    @staticmethod
    def estimate_tg_reg_date(tg_id: int) -> dict:
        checkpoints = [
            (1000000, 1380585600), (10000000, 1414800000), (50000000, 1451606400),
            (100000000, 1475280000), (300000000, 1498867200), (500000000, 1525132800),
            (800000000, 1559347200), (1100000000, 1588291200), (1500000000, 1609459200),
            (2000000000, 1633046400), (5000000000, 1654041600), (6000000000, 1685577600),
            (7000000000, 1711929600), (7500000000, 1735689600), (8000000000, 1767225600)
        ]
        if tg_id <= checkpoints[0][0]:
            est_ts = checkpoints[0][1]
        elif tg_id >= checkpoints[-1][0]:
            est_ts = checkpoints[-1][1]
        else:
            est_ts = checkpoints[0][1]
            for i in range(len(checkpoints) - 1):
                id1, ts1 = checkpoints[i]
                id2, ts2 = checkpoints[i + 1]
                if id1 <= tg_id <= id2:
                    est_ts = int(ts1 + ((tg_id - id1) / (id2 - id1)) * (ts2 - ts1))
                    break
        return {
            "telegram_id": tg_id,
            "estimated_registration": datetime.fromtimestamp(est_ts, tz=timezone.utc).strftime("%Y-%m (%B %Y)")
        }

    async def telegram_web_profile(self, username: str, session: aiohttp.ClientSession) -> dict:
        url = f"https://t.me/{username}"
        try:
            async with session.get(url, headers=self.headers) as r:
                if r.status == 200:
                    soup = BeautifulSoup(await r.text(), "html.parser")
                    title = soup.find("div", class_="tgme_page_title")
                    desc = soup.find("div", class_="tgme_page_description")
                    if title:
                        return {
                            "exists": True,
                            "url": url,
                            "display_name": title.get_text(strip=True),
                            "bio": desc.get_text(strip=True)[:150] if desc else ""
                        }
        except Exception:
            pass
        return {"exists": False}

    async def check_second_nicknames(self, username: str, session: aiohttp.ClientSession) -> dict:
        base = username.lower()
        clean = re.sub(r"[_\.\-]", "", base)
        variants = sorted(list({
            f"{clean}_", f"_{clean}", f"{clean}1", f"real_{clean}",
            f"{clean}.official", base.replace("_", "."), base.replace(".", "_")
        } - {base}))[:6]

        found_tg = []
        for v in variants[:4]:
            prof = await self.telegram_web_profile(v, session)
            if prof.get("exists"):
                found_tg.append(f"@{v} ({prof.get('display_name')})")
        return {"generated_aliases": variants, "active_in_telegram": found_tg}

    async def gravatar_lookup(self, email: str, session: aiohttp.ClientSession) -> dict:
        h = hashlib.md5(email.strip().lower().encode()).hexdigest()
        try:
            async with session.get(f"https://en.gravatar.com/{h}.json") as r:
                if r.status == 200:
                    entry = (await r.json()).get("entry", [{}])[0]
                    return {
                        "username": entry.get("preferredUsername"),
                        "display_name": entry.get("displayName"),
                        "full_name": entry.get("name", {}).get("formatted"),
                        "location": entry.get("currentLocation")
                    }
        except Exception:
            pass
        return {}

    @staticmethod
    def dns_and_ip_resolve(domain: str) -> dict:
        res = {"A": [], "MX": [], "TXT": [], "NS": []}
        for rtype in res.keys():
            try:
                answers = dns.resolver.resolve(domain, rtype, lifetime=5)
                res[rtype] = [str(r) for r in answers]
            except Exception:
                pass
        return res

    async def crtsh_subdomains(self, domain: str, session: aiohttp.ClientSession) -> list[str]:
        try:
            async with session.get(f"https://crt.sh/?q=%.{domain}&output=json") as r:
                if r.status == 200:
                    data = await r.json()
                    subs = {s.strip() for item in data for s in item.get("name_value", "").split("\n")}
                    return sorted(list(subs))[:60]
        except Exception:
            pass
        return []

    @staticmethod
    def phone_lookup(phone: str) -> dict:
        try:
            p = phonenumbers.parse(phone, None)
            return {
                "formatted": phonenumbers.format_number(p, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
                "valid": phonenumbers.is_valid_number(p),
                "region": geocoder.description_for_number(p, "ru"),
                "carrier": carrier.name_for_number(p, "ru") or "Не определён (MNP)",
                "timezone": list(pn_timezone.time_zones_for_number(p))
            }
        except Exception as e:
            return {"error": str(e)}

    @staticmethod
    def extract_exif(file_bytes: bytes) -> dict:
        tags = exifread.process_file(BytesIO(file_bytes), details=False)
        return {k: str(v) for k, v in tags.items() if k not in ("JPEGThumbnail", "TIFFThumbnail")}

    async def search_local_dumps(self, query: str) -> list[str]:
        dumps_dir = "./local_dumps"
        if not os.path.exists(dumps_dir):
            return []
        results = []
        try:
            for fname in os.listdir(dumps_dir):
                fpath = os.path.join(dumps_dir, fname)
                if os.path.isfile(fpath) and fname.endswith((".txt", ".csv", ".tsv", ".log")):
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            if query.lower() in line.lower():
                                results.append(f"[{fname}] {line.strip()[:250]}")
                                if len(results) >= 15:
                                    return results
        except Exception:
            pass
        return results

    # ==================== ГЛАВНЫЙ ОРКЕСТРАТОР (МАКСИМАЛЬНЫЙ СБОР) ====================

    async def execute_scan(self, target: str, target_type: TargetType, deep: bool = False) -> tuple[str, str]:
        if await is_target_blocked(target):
            msg = "🔒 Информация по данному запросу защищена и скрыта администратором."
            return msg, msg

        p1_target = f"{target} ({target_type.value.upper()})"
        p2_name = "Не обнаружено"
        p3_tg = "Не найден"
        p4_vk = "Не найден"
        p5_tt_yt = "TikTok: нет | YouTube: нет"
        p6_platforms = "Нет совпадений"
        p7_leaks = "Утечек не обнаружено"
        p8_stealers = "Чисто (в логах инфостилеров не найден)"
        p9_geo_net = "Скрыт (в открытых профилях и дампах не засвечен)"
        p10_aliases = "Не обнаружено"

        raw_sections: list[tuple[str, any]] = []

        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            # --- 1. ПОИСК ПО НИКНЕЙМУ ---
            if target_type == TargetType.USERNAME:
                tg_prof, vk_prof, tt_yt, ext_soc, breaches, aliases, maigret_out = await asyncio.gather(
                    self.telegram_web_profile(target, session),
                    self.vk_lookup(target, session),
                    self.tiktok_youtube_lookup(target, session),
                    self.extended_social_apis(target, session),
                    self.deep_breach_intelligence(target, target_type, session),
                    self.check_second_nicknames(target, session),
                    self.run_maigret(target, full=deep)
                )

                extracted_contacts = await self.extract_contacts_and_ip_by_nick(
                    target, vk_prof if isinstance(vk_prof, dict) else {}, tg_prof, breaches, ext_soc, session
                )

                names_found = list(ext_soc.get("_summary", {}).get("names", []))
                if isinstance(vk_prof, dict) and vk_prof.get("found"):
                    names_found.insert(0, f"{vk_prof.get('full_name')} (ВК)")
                    p4_vk = f"{vk_prof.get('url')} ({vk_prof.get('full_name')})"
                if tg_prof.get("exists"):
                    names_found.insert(0, f"{tg_prof.get('display_name')} (TG)")
                    p3_tg = f"{tg_prof.get('url')} — Имя: {tg_prof.get('display_name')}"
                if names_found:
                    p2_name = " / ".join(dict.fromkeys(names_found))

                p5_tt_yt = f"TikTok: {tt_yt['tiktok']} | YouTube: {tt_yt['youtube']}"

                found_sites = list(ext_soc.get("_summary", {}).get("profiles", []))
                for line in maigret_out.splitlines():
                    if "[+]" in line:
                        s_name = line.strip().split()[1].rstrip(":")
                        if s_name not in found_sites:
                            found_sites.append(s_name)
                p6_platforms = (
                    f"Найдено ({len(found_sites)}): {', '.join(found_sites[:10])}"
                    if found_sites else "Совпадений в топ-сайтах нет"
                )

                if breaches["databases"]:
                    p7_leaks = f"Найдено баз ({len(breaches['databases'])}): {', '.join(breaches['databases'][:6])} | Поля: {', '.join(breaches['fields'][:5])}"
                p8_stealers = breaches["stealers"]

                contact_parts = []
                if extracted_contacts["phones"]:
                    contact_parts.append(f"📞 Тел: {', '.join(extracted_contacts['phones'])}")
                if extracted_contacts["ips"]:
                    contact_parts.append(f"🌐 IP: {', '.join(extracted_contacts['ips'])}")
                if extracted_contacts["emails"]:
                    contact_parts.append(f"✉️ Email: {', '.join(extracted_contacts['emails'])}")
                locs = list(ext_soc.get("_summary", {}).get("locations", []))
                if isinstance(vk_prof, dict) and vk_prof.get("city"):
                    locs.insert(0, vk_prof["city"])
                if locs:
                    contact_parts.append(f"📍 Гео: {', '.join(locs[:3])}")
                if contact_parts:
                    p9_geo_net = " | ".join(contact_parts)

                alias_parts = []
                if aliases.get("active_in_telegram"):
                    alias_parts.append("TG-алиасы: " + ", ".join(aliases["active_in_telegram"]))
                else:
                    alias_parts.append("Вероятные ники: " + ", ".join(aliases.get("generated_aliases", [])[:4]))
                if breaches.get("commits"):
                    alias_parts.append("GitHub: " + breaches["commits"][0])
                p10_aliases = " | ".join(alias_parts)

                raw_sections.extend([
                    ("НАЙДЕННЫЕ ТЕЛЕФОНЫ / IP / EMAIL ПО НИКУ", extracted_contacts),
                    ("STEAM / GITHUB / GITLAB / KEYBASE / REDDIT / CHESS / HABR", ext_soc),
                    ("TELEGRAM ПРОФИЛЬ", tg_prof),
                    ("ВКОНТАКТЕ", vk_prof),
                    ("TIKTOK И YOUTUBE", tt_yt),
                    ("СЛИТЫЕ БАЗЫ И УТЕЧКИ", breaches),
                    ("ВОЗМОЖНЫЕ ВТОРЫЕ НИКНЕЙМЫ", aliases),
                    ("MAIGRET (ПОЛНЫЙ СПИСОК АККАУНТОВ)", maigret_out)
                ])

            # --- 2. ПОИСК ПО EMAIL ---
            elif target_type == TargetType.EMAIL:
                grav, extra_em, breaches, holehe_out = await asyncio.gather(
                    self.gravatar_lookup(target, session),
                    self.email_extra_osint(target, session),
                    self.deep_breach_intelligence(target, target_type, session),
                    self.run_holehe(target)
                )
                duo = extra_em.get("duolingo") or {}
                pivot_nick = grav.get("username") or duo.get("username") or target.split("@")[0]

                if await is_target_blocked(pivot_nick):
                    msg = "🔒 Информация по данному запросу защищена и скрыта администратором."
                    return msg, msg

                names_list = []
                if grav.get("full_name") or grav.get("display_name"):
                    names_list.append(f"{grav.get('full_name') or grav.get('display_name')} (Gravatar)")
                if duo.get("name"):
                    names_list.append(f"{duo['name']} (Duolingo)")
                if extra_em.get("pgp_uid"):
                    names_list.append(f"{extra_em['pgp_uid']} (PGP Key)")
                if breaches.get("commits"):
                    names_list.append(breaches["commits"][0].split("<")[0].strip() + " (GitHub)")
                if names_list:
                    p2_name = " / ".join(names_list)

                used_services = [l.strip().replace("[+]", "").strip() for l in holehe_out.splitlines() if "[+]" in l]
                if duo:
                    used_services.insert(0, f"Duolingo (@{duo.get('username')})")
                p6_platforms = (
                    f"Регистраций почты ({len(used_services)}): {', '.join(used_services[:9])}"
                    if used_services else "Активных регистраций не найдено"
                )

                if breaches["databases"]:
                    p7_leaks = f"Найдено баз ({len(breaches['databases'])}): {', '.join(breaches['databases'][:6])} | Поля: {', '.join(breaches['fields'][:5])}"
                p8_stealers = breaches["stealers"]
                p9_geo_net = f"Гео: {grav.get('location') or 'н/д'} | MX-сервер: {', '.join(extra_em.get('mail_server') or [target.split('@')[-1]])}"
                p10_aliases = f"Связанный ник: @{pivot_nick}" + (f" | GitHub: {breaches['commits'][0]}" if breaches.get("commits") else "")

                raw_sections.extend([
                    ("GRAVATAR & DUOLINGO & PGP", {"gravatar": grav, "extra": extra_em}),
                    ("СЛИТЫЕ БАЗЫ И УТЕЧКИ", breaches),
                    ("HOLEHE (СЕРВИСЫ)", holehe_out)
                ])

                if len(pivot_nick) >= 4:
                    tg_p, vk_p, tt_yt_p, ext_p = await asyncio.gather(
                        self.telegram_web_profile(pivot_nick, session),
                        self.vk_lookup(pivot_nick, session),
                        self.tiktok_youtube_lookup(pivot_nick, session),
                        self.extended_social_apis(pivot_nick, session)
                    )
                    if tg_p.get("exists"):
                        p3_tg = f"По нику @{pivot_nick}: {tg_p.get('url')} ({tg_p.get('display_name')})"
                    if isinstance(vk_p, dict) and vk_p.get("found"):
                        p4_vk = f"По нику @{pivot_nick}: {vk_p.get('url')} ({vk_p.get('full_name')})"
                        if p2_name == "Не обнаружено":
                            p2_name = f"{vk_p.get('full_name')} (ВК по нику почты)"
                    p5_tt_yt = f"TikTok: {tt_yt_p['tiktok']} | YouTube: {tt_yt_p['youtube']}"

                    raw_sections.append((f"🔗 PIVOTING ПО НИКУ @{pivot_nick}", {"tg": tg_p, "vk": vk_p, "tt_yt": tt_yt_p, "socials": ext_p}))

            # --- 3. ПОИСК ПО ТЕЛЕФОНУ ---
            elif target_type == TargetType.PHONE:
                p_meta = self.phone_lookup(target)
                p_extra, ig_out = await asyncio.gather(
                    self.phone_extra_osint(target, session),
                    self.run_ignorant(target)
                )
                hw = p_extra.get("htmlweb_mnp", {})
                oper = hw.get("operator_brand") or hw.get("operator") or p_meta.get("carrier")
                reg_city = f"{hw.get('region') or p_meta.get('region')}, {hw.get('city') or ''}".strip(", ")
                p9_geo_net = f"Регион: {reg_city} | Оператор (MNP): {oper} | Пояс: {', '.join(p_meta.get('timezone', []))}"

                p3_tg = f"Прямая ссылка TG: {p_extra['messengers']['telegram']} | WhatsApp: {p_extra['messengers']['whatsapp']}"
                p7_leaks = p_extra.get("leakcheck_phone", "Не найдено")

                used_ig = [l.strip() for l in ig_out.splitlines() if "[+]" in l]
                mentions = [m["title"] for m in p_extra.get("web_mentions", [])[:3]]
                p6_platforms = f"Ignorant: {', '.join(used_ig) or 'нет'} | Веб-упоминаний: {len(p_extra.get('web_mentions', []))} ({'; '.join(mentions)})"

                raw_sections.extend([
                    ("МЕТАДАННЫЕ И MNP ОПЕРАТОР", {"phonenumbers": p_meta, "htmlweb_mnp": hw}),
                    ("МЕССЕНДЖЕРЫ, LEAKCHECK И ВЕБ-УПОМИНАНИЯ", p_extra),
                    ("IGNORANT", ig_out)
                ])

            # --- 4. ПОИСК ПО TELEGRAM / VK ID ---
            elif target_type == TargetType.TG_ID:
                reg = self.estimate_tg_reg_date(int(target))
                vk_id_info = await self.vk_lookup(target, session)
                p3_tg = f"ID: {target} | Оценка даты регистрации в TG: {reg['estimated_registration']}"
                if isinstance(vk_id_info, dict) and vk_id_info.get("found"):
                    p2_name = f"{vk_id_info.get('full_name')} (ВК id{target})"
                    p4_vk = f"{vk_id_info.get('url')} ({vk_id_info.get('full_name')})"
                raw_sections.extend([("TELEGRAM ID АНАЛИЗ", reg), ("ВКОНТАКТЕ ПО ID", vk_id_info)])

            # --- 5. ПОИСК ПО ИМЕНИ И ФАМИЛИИ ---
            elif target_type == TargetType.FULLNAME:
                p2_name = target
                vk_list = await self.vk_lookup(target, session, by_name=True)
                if isinstance(vk_list, list) and vk_list:
                    top_matches = [f"{u['full_name']} ({u.get('city') or 'н/д'}) - {u['url']}" for u in vk_list[:4]]
                    p4_vk = " ; ".join(top_matches)
                else:
                    p4_vk = "Анкет в открытом доступе не найдено"
                raw_sections.append(("ПОИСК ПО ФИО (ВК / ОК / РЕЕСТРЫ ИП И ООО)", vk_list))

            # --- 6. ПОИСК ПО ДОМЕНУ И IP (С SHODAN INTERNETDB!) ---
            elif target_type in (TargetType.DOMAIN, TargetType.IP):
                if target_type == TargetType.DOMAIN:
                    dns_info = self.dns_and_ip_resolve(target)
                    subs, breaches = await asyncio.gather(
                        self.crtsh_subdomains(target, session),
                        self.deep_breach_intelligence(target, target_type, session)
                    )
                    first_ip = dns_info["A"][0] if dns_info.get("A") else None
                    ip_intel = await self.ip_deep_intelligence(first_ip, session) if first_ip else {}
                    shodan = ip_intel.get("shodan_internetdb", {})
                    geo = ip_intel.get("geo", {})

                    p6_platforms = f"Поддоменов (crt.sh): {len(subs)} ({', '.join(subs[:5])}) | Открытые порты (Shodan): {shodan.get('ports', [])}"
                    p7_leaks = f"Уязвимости CVE (Shodan): {', '.join(shodan.get('vulns', [])[:5]) or 'нет'}"
                    p8_stealers = breaches["stealers"]
                    p9_geo_net = f"IP: {first_ip} ({geo.get('country')}, {geo.get('isp')}) {' '.join(ip_intel.get('flags', []))}"
                    raw_sections.extend([("DNS", dns_info), ("SHODAN & IP INTEL", ip_intel), ("CRT.SH ПОДДОМЕНЫ", subs), ("УТЕЧКИ ДОМЕНА", breaches)])
                else:
                    ip_intel = await self.ip_deep_intelligence(target, session)
                    shodan = ip_intel.get("shodan_internetdb", {})
                    geo = ip_intel.get("geo", {})
                    p6_platforms = f"Открытые порты (Shodan): {shodan.get('ports', [])} | Хосты: {shodan.get('hostnames', [])}"
                    p7_leaks = f"Уязвимости CVE: {', '.join(shodan.get('vulns', [])[:6]) or 'нет'} | ПО: {', '.join(shodan.get('cpes', [])[:4])}"
                    p9_geo_net = f"{geo.get('country')}, {geo.get('city')} | ISP: {geo.get('isp')} ({geo.get('as')}) | {' '.join(ip_intel.get('flags', []))}"
                    raw_sections.append(("SHODAN INTERNETDB & IP-API", ip_intel))

        short_10 = "\n".join([
            "📋 ВЫЖИМКА РАЗВЕДКИ (10 ПУНКТОВ)",
            "━━━━━━━━━━━━━━━━━━",
            f"1. 🎯 Объект: {p1_target}",
            f"2. 👤 Имя / ФИО: {p2_name}",
            f"3. 💬 Telegram: {p3_tg}",
            f"4. 🌐 ВКонтакте / Реестры: {p4_vk}",
            f"5. 🎬 TikTok и YouTube: {p5_tt_yt}",
            f"6. 📱 Сервисы и площадки: {p6_platforms}",
            f"7. 🚨 Слитые базы и уязвимости: {p7_leaks}",
            f"8. 🦠 Логи инфостилеров: {p8_stealers}",
            f"9. 📡 Телефон / IP / Email / Гео: {p9_geo_net}",
            f"10. 🔄 Вторые ники и связи: {p10_aliases}",
        ])

        if not deep:
            return short_10, short_10

        full_blocks = [
            short_10,
            "",
            "==================================================",
            " ПОЛНЫЙ РАЗВЁРНУТЫЙ ОТЧЁТ (DEEP MODE + PIVOTING)",
            "=================================================="
        ]
        for title, data in raw_sections:
            formatted = json.dumps(data, indent=2, ensure_ascii=False) if isinstance(data, (dict, list)) else str(data)
            full_blocks.append(f"\n[ {title} ]\n{'-' * len(title)}\n{formatted}")

        full_text = "\n".join(full_blocks)
        return short_10, full_text