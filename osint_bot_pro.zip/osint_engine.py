import asyncio
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone
from io import BytesIO

import aiohttp
import dns.resolver
import exifread
import phonenumbers
from bs4 import BeautifulSoup
from phonenumbers import carrier, geocoder, timezone as pn_timezone

from config import settings
from database import is_target_blocked
from validators import TargetType


async def run_cli(args: list[str], timeout: int = 60) -> str:
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        out = stdout.decode("utf-8", errors="ignore").strip()
        return out if out else "Совпадений не найдено."
    except FileNotFoundError:
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", *args,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            out = stdout.decode("utf-8", errors="ignore").strip()
            return out if out else "Совпадений не найдено."
        except Exception:
            return f"Утилита {args[0]} не установлена."
    except asyncio.TimeoutError:
        return f"Таймаут ({timeout} с)."
    except Exception as e:
        return f"Ошибка {args[0]}: {e}"


class OSINTEngine:
    def __init__(self):
        self.timeout = aiohttp.ClientTimeout(total=25)
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7"
        }

    async def run_maigret(self, username: str, full: bool = False) -> str:
        sites = "300" if full else "50"
        t_out = 150 if full else 45
        return await run_cli(["maigret", username, "--top-sites", sites, "--no-color", "--timeout", "8"], timeout=t_out)

    async def run_holehe(self, email: str) -> str:
        return await run_cli(["holehe", email, "--only-used", "--no-color"], timeout=45)

    async def run_ignorant(self, phone: str) -> str:
        clean_digits = re.sub(r"\D", "", phone)
        if clean_digits.startswith("7") and len(clean_digits) == 11:
            return await run_cli(["ignorant", "7", clean_digits[1:], "--only-used", "--no-color"], timeout=40)
        return "Не найдено"

    async def tiktok_youtube_lookup(self, username: str, session: aiohttp.ClientSession) -> dict:
        res = {"tiktok": "Не найден", "youtube": "Не найден"}

        tt_url = f"https://www.tiktok.com/@{username}"
        try:
            async with session.get(tt_url, headers=self.headers) as r:
                if r.status == 200:
                    html = await r.text()
                    soup = BeautifulSoup(html, "html.parser")
                    title_el = soup.find("title")
                    title_txt = title_el.get_text(strip=True) if title_el else ""
                    if title_txt and "TikTok" in title_txt and f"@{username.lower()}" in html.lower():
                        clean_t = title_txt.replace("| TikTok", "").strip()
                        res["tiktok"] = f"{clean_t} ({tt_url})"
        except Exception:
            pass

        yt_url = f"https://www.youtube.com/@{username}"
        try:
            async with session.get(yt_url, headers=self.headers) as r:
                if r.status == 200:
                    html = await r.text()
                    soup = BeautifulSoup(html, "html.parser")
                    og_title = soup.find("meta", property="og:title")
                    if og_title and og_title.has_attr("content"):
                        res["youtube"] = f"{og_title['content']} ({yt_url})"
        except Exception:
            pass

        return res

    async def deep_breach_intelligence(self, target: str, target_type: TargetType, session: aiohttp.ClientSession) -> dict:
        intel = {"databases": [], "fields": [], "stealers": "Чисто", "commits": [], "xposed_details": []}

        if target_type in (TargetType.EMAIL, TargetType.USERNAME):
            try:
                async with session.get(f"https://leakcheck.io/api/public?check={target}", headers=self.headers) as r:
                    if r.status == 200:
                        data = await r.json()
                        if data.get("success") and data.get("found", 0) > 0:
                            intel["fields"] = data.get("fields", [])
                            intel["databases"] = [
                                f"{s.get('name')} ({s.get('date') or 'н/д'})"
                                for s in data.get("sources", [])
                            ]
            except Exception:
                pass

        if target_type == TargetType.EMAIL:
            try:
                async with session.get(f"https://api.xposedornot.com/v1/breach-analytics?email={target}", headers=self.headers) as r:
                    if r.status == 200:
                        data = await r.json()
                        details = data.get("ExposedBreaches", {}).get("breaches_details", [])
                        for b in details[:12]:
                            b_name = f"{b.get('breach')} ({b.get('xposed_date')})"
                            if b_name not in intel["databases"]:
                                intel["databases"].append(b_name)
                            intel["xposed_details"].append({
                                "db": b.get("breach"),
                                "year": b.get("xposed_date"),
                                "data": b.get("xposed_data")
                            })
            except Exception:
                pass

        if target_type in (TargetType.EMAIL, TargetType.USERNAME, TargetType.DOMAIN):
            ep_map = {
                TargetType.EMAIL: f"search-by-email?email={target}",
                TargetType.USERNAME: f"search-by-username?username={target}",
                TargetType.DOMAIN: f"search-by-domain?domain={target}"
            }
            try:
                url = f"https://cavalier.hudsonrock.com/api/json/v2/osint-tools/{ep_map[target_type]}"
                async with session.get(url, headers=self.headers) as r:
                    if r.status == 200:
                        data = await r.json()
                        stealers = data.get("stealers", [])
                        if stealers:
                            intel["stealers"] = f"Обнаружено записей в логах инфостилеров: {len(stealers)}"
                            intel["stealers_raw"] = stealers[:5]
            except Exception:
                pass

        if target_type in (TargetType.EMAIL, TargetType.USERNAME):
            try:
                gh_headers = {**self.headers, "Accept": "application/vnd.github.cloak-preview+json"}
                q = f"author-email:{target}" if target_type == TargetType.EMAIL else f"author:{target}"
                async with session.get(f"https://api.github.com/search/commits?q={q}&per_page=5", headers=gh_headers) as r:
                    if r.status == 200:
                        for item in (await r.json()).get("items", []):
                            a = item.get("commit", {}).get("author", {})
                            repo = item.get("repository", {}).get("full_name")
                            entry = f"{a.get('name')} <{a.get('email')}> ({repo})"
                            if entry not in intel["commits"]:
                                intel["commits"].append(entry)
            except Exception:
                pass

        return intel

    async def vk_lookup(self, query: str, session: aiohttp.ClientSession, by_name: bool = False) -> dict | list:
        if not settings.VK_SERVICE_TOKEN and not by_name:
            url = f"https://vk.com/{query}"
            try:
                async with session.get(url, headers=self.headers) as r:
                    if r.status == 200:
                        soup = BeautifulSoup(await r.text(), "html.parser")
                        title = soup.find("title")
                        og_title = soup.find("meta", property="og:title")
                        if title and ("ВКонтакте" in title.text or "VK" in title.text):
                            name = og_title["content"] if (og_title and og_title.has_attr("content")) else title.text.split("|")[0].strip()
                            return {"found": True, "full_name": name, "url": url}
            except Exception:
                pass
            return {"found": False}

        if by_name and settings.VK_SERVICE_TOKEN:
            url = "https://api.vk.com/method/users.search"
            params = {"q": query, "count": 5, "fields": "bdate,city,domain", "access_token": settings.VK_SERVICE_TOKEN, "v": "5.199", "lang": "ru"}
            async with session.get(url, params=params) as r:
                items = (await r.json()).get("response", {}).get("items", [])
                return [
                    {
                        "id": u.get("id"),
                        "full_name": f"{u.get('first_name')} {u.get('last_name')}",
                        "city": u.get("city", {}).get("title"),
                        "bdate": u.get("bdate"),
                        "url": f"https://vk.com/{u.get('domain')}"
                    }
                    for u in items
                ]

        if settings.VK_SERVICE_TOKEN:
            url = "https://api.vk.com/method/users.get"
            params = {"user_ids": query, "fields": "first_name,last_name,bdate,city,domain,status", "access_token": settings.VK_SERVICE_TOKEN, "v": "5.199", "lang": "ru"}
            async with session.get(url, params=params) as r:
                users = (await r.json()).get("response", [])
                if users:
                    u = users[0]
                    return {
                        "found": True,
                        "vk_id": u.get("id"),
                        "full_name": f"{u.get('first_name', '')} {u.get('last_name', '')}".strip(),
                        "url": f"https://vk.com/{u.get('domain')}",
                        "bdate": u.get("bdate", "Скрыта"),
                        "city": u.get("city", {}).get("title", "Скрыт"),
                        "status": u.get("status", "")
                    }
        return {"found": False}

    @staticmethod
    def estimate_tg_reg_date(tg_id: int) -> dict:
        checkpoints = [
            (1000000, 1380585600), (10000000, 1414800000), (50000000, 1451606400),
            (100000000, 1475280000), (300000000, 1498867200), (500000000, 1525132800),
            (800000000, 1559347200), (1100000000, 1588291200), (1500000000, 1609459200),
            (2000000000, 1633046400), (5000000000, 1654041600), (6000000000, 1685577600),
            (7000000000, 1711929600), (7500000000, 1735689600), (8000000000, 1767225600)
        ]
        if tg_id <= checkpoints[0][0]:
            est_ts = checkpoints[0][1]
        elif tg_id >= checkpoints[-1][0]:
            est_ts = checkpoints[-1][1]
        else:
            est_ts = checkpoints[0][1]
            for i in range(len(checkpoints) - 1):
                id1, ts1 = checkpoints[i]
                id2, ts2 = checkpoints[i + 1]
                if id1 <= tg_id <= id2:
                    est_ts = int(ts1 + ((tg_id - id1) / (id2 - id1)) * (ts2 - ts1))
                    break
        return {
            "telegram_id": tg_id,
            "estimated_registration": datetime.fromtimestamp(est_ts, tz=timezone.utc).strftime("%Y-%m (%B %Y)")
        }

    async def telegram_web_profile(self, username: str, session: aiohttp.ClientSession) -> dict:
        url = f"https://t.me/{username}"
        try:
            async with session.get(url, headers=self.headers) as r:
                if r.status == 200:
                    soup = BeautifulSoup(await r.text(), "html.parser")
                    title = soup.find("div", class_="tgme_page_title")
                    desc = soup.find("div", class_="tgme_page_description")
                    if title:
                        return {
                            "exists": True,
                            "url": url,
                            "display_name": title.get_text(strip=True),
                            "bio": desc.get_text(strip=True)[:100] if desc else ""
                        }
        except Exception:
            pass
        return {"exists": False}

    async def check_second_nicknames(self, username: str, session: aiohttp.ClientSession) -> dict:
        base = username.lower()
        clean = re.sub(r"[_\.\-]", "", base)
        variants = sorted(list({
            f"{clean}_", f"_{clean}", f"{clean}1", f"real_{clean}",
            f"{clean}.official", base.replace("_", "."), base.replace(".", "_")
        } - {base}))[:6]

        found_tg = []
        for v in variants[:4]:
            prof = await self.telegram_web_profile(v, session)
            if prof.get("exists"):
                found_tg.append(f"@{v} ({prof.get('display_name')})")
        return {"generated_aliases": variants, "active_in_telegram": found_tg}

    async def gravatar_lookup(self, email: str, session: aiohttp.ClientSession) -> dict:
        h = hashlib.md5(email.strip().lower().encode()).hexdigest()
        try:
            async with session.get(f"https://en.gravatar.com/{h}.json") as r:
                if r.status == 200:
                    entry = (await r.json()).get("entry", [{}])[0]
                    return {
                        "username": entry.get("preferredUsername"),
                        "display_name": entry.get("displayName"),
                        "full_name": entry.get("name", {}).get("formatted"),
                        "location": entry.get("currentLocation")
                    }
        except Exception:
            pass
        return {}

    async def ip_free_lookup(self, ip: str, session: aiohttp.ClientSession) -> dict:
        try:
            async with session.get(f"https://ipwho.is/{ip}") as r:
                if r.status == 200:
                    d = await r.json()
                    return {
                        "ip": d.get("ip"),
                        "country": d.get("country"),
                        "city": d.get("city"),
                        "isp": d.get("connection", {}).get("isp"),
                        "asn": d.get("connection", {}).get("asn")
                    }
        except Exception:
            pass
        return {}

    @staticmethod
    def dns_and_ip_resolve(domain: str) -> dict:
        res = {"A": [], "MX": [], "TXT": [], "NS": []}
        for rtype in res.keys():
            try:
                answers = dns.resolver.resolve(domain, rtype, lifetime=5)
                res[rtype] = [str(r) for r in answers]
            except Exception:
                pass
        return res

    async def crtsh_subdomains(self, domain: str, session: aiohttp.ClientSession) -> list[str]:
        try:
            async with session.get(f"https://crt.sh/?q=%.{domain}&output=json") as r:
                if r.status == 200:
                    data = await r.json()
                    subs = {s.strip() for item in data for s in item.get("name_value", "").split("\n")}
                    return sorted(list(subs))[:60]
        except Exception:
            pass
        return []

    @staticmethod
    def phone_lookup(phone: str) -> dict:
        try:
            p = phonenumbers.parse(phone, None)
            return {
                "formatted": phonenumbers.format_number(p, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
                "valid": phonenumbers.is_valid_number(p),
                "region": geocoder.description_for_number(p, "ru"),
                "carrier": carrier.name_for_number(p, "ru") or "Не определён (MNP)",
                "timezone": list(pn_timezone.time_zones_for_number(p))
            }
        except Exception as e:
            return {"error": str(e)}

    @staticmethod
    def extract_exif(file_bytes: bytes) -> dict:
        tags = exifread.process_file(BytesIO(file_bytes), details=False)
        return {k: str(v) for k, v in tags.items() if k not in ("JPEGThumbnail", "TIFFThumbnail")}

    async def execute_scan(self, target: str, target_type: TargetType, deep: bool = False) -> tuple[str, str]:
        if await is_target_blocked(target):
            msg = "🔒 Информация по данному запросу защищена и скрыта администратором."
            return msg, msg

        p1_target = f"{target} ({target_type.value.upper()})"
        p2_name = "Не обнаружено"
        p3_tg = "Не найден"
        p4_vk = "Не найден"
        p5_tt_yt = "TikTok: нет | YouTube: нет"
        p6_platforms = "Нет совпадений"
        p7_leaks = "Утечек не обнаружено"
        p8_stealers = "Чисто (в логах инфостилеров не найден)"
        p9_geo_net = "Нет данных"
        p10_aliases = "Не обнаружено"

        raw_sections: list[tuple[str, any]] = []

        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            if target_type == TargetType.USERNAME:
                tg_prof, vk_prof, tt_yt, breaches, aliases, maigret_out = await asyncio.gather(
                    self.telegram_web_profile(target, session),
                    self.vk_lookup(target, session),
                    self.tiktok_youtube_lookup(target, session),
                    self.deep_breach_intelligence(target, target_type, session),
                    self.check_second_nicknames(target, session),
                    self.run_maigret(target, full=deep)
                )

                names_found = []
                if isinstance(vk_prof, dict) and vk_prof.get("found"):
                    names_found.append(f"{vk_prof.get('full_name')} (ВК)")
                    p4_vk = f"{vk_prof.get('url')} ({vk_prof.get('full_name')})"
                if tg_prof.get("exists"):
                    names_found.append(f"{tg_prof.get('display_name')} (TG)")
                    p3_tg = f"{tg_prof.get('url')} — Имя: {tg_prof.get('display_name')}"
                if names_found:
                    p2_name = " / ".join(names_found)

                p5_tt_yt = f"TikTok: {tt_yt['tiktok']} | YouTube: {tt_yt['youtube']}"

                found_sites = [line.strip() for line in maigret_out.splitlines() if "[+]" in line]
                p6_platforms = (
                    f"Найдено профилей: {len(found_sites)} ({', '.join(s.split()[1].rstrip(':') for s in found_sites[:6])})"
                    if found_sites else "Совпадений в топ-сайтах нет"
                )

                if breaches["databases"]:
                    p7_leaks = f"Найдено баз ({len(breaches['databases'])}): {', '.join(breaches['databases'][:5])}"
                p8_stealers = breaches["stealers"]

                if isinstance(vk_prof, dict) and vk_prof.get("city"):
                    p9_geo_net = f"Город (из ВК): {vk_prof.get('city')}"

                alias_parts = []
                if aliases.get("active_in_telegram"):
                    alias_parts.append("TG-алиасы: " + ", ".join(aliases["active_in_telegram"]))
                else:
                    alias_parts.append("Вероятные ники: " + ", ".join(aliases.get("generated_aliases", [])[:4]))
                if breaches.get("commits"):
                    alias_parts.append("GitHub: " + breaches["commits"][0])
                p10_aliases = " | ".join(alias_parts)

                raw_sections.extend([
                    ("TELEGRAM ПРОФИЛЬ", tg_prof),
                    ("ВКОНТАКТЕ", vk_prof),
                    ("TIKTOK И YOUTUBE", tt_yt),
                    ("СЛИТЫЕ БАЗЫ И УТЕЧКИ", breaches),
                    ("ВОЗМОЖНЫЕ ВТОРЫЕ НИКНЕЙМЫ", aliases),
                    ("MAIGRET (ПОЛНЫЙ СПИСОК АККАУНТОВ)", maigret_out)
                ])

            elif target_type == TargetType.EMAIL:
                grav, breaches, holehe_out = await asyncio.gather(
                    self.gravatar_lookup(target, session),
                    self.deep_breach_intelligence(target, target_type, session),
                    self.run_holehe(target)
                )
                pivot_nick = grav.get("username") or target.split("@")[0]

                if await is_target_blocked(pivot_nick):
                    msg = "🔒 Информация по данному запросу защищена и скрыта администратором."
                    return msg, msg

                if grav.get("full_name") or grav.get("display_name"):
                    p2_name = f"{grav.get('full_name') or grav.get('display_name')} (Gravatar)"
                elif breaches.get("commits"):
                    p2_name = breaches["commits"][0].split("<")[0].strip() + " (GitHub)"

                used_services = [l.strip() for l in holehe_out.splitlines() if "[+]" in l]
                p6_platforms = (
                    f"Регистраций почты ({len(used_services)}): {', '.join(s.replace('[+]', '').strip() for s in used_services[:7])}"
                    if used_services else "Активных регистраций не найдено"
                )

                if breaches["databases"]:
                    p7_leaks = f"Найдено баз ({len(breaches['databases'])}): {', '.join(breaches['databases'][:6])} | Поля: {', '.join(breaches['fields'][:5])}"
                p8_stealers = breaches["stealers"]
                p9_geo_net = grav.get("location") or f"Почтовый домен: {target.split('@')[-1]}"
                p10_aliases = f"Возможный ник: @{pivot_nick}" + (f" | GitHub: {breaches['commits'][0]}" if breaches.get("commits") else "")

                raw_sections.extend([
                    ("GRAVATAR", grav),
                    ("СЛИТЫЕ БАЗЫ И УТЕЧКИ", breaches),
                    ("HOLEHE (СЕРВИСЫ)", holehe_out)
                ])

                if len(pivot_nick) >= 4:
                    tg_p, vk_p, tt_yt_p = await asyncio.gather(
                        self.telegram_web_profile(pivot_nick, session),
                        self.vk_lookup(pivot_nick, session),
                        self.tiktok_youtube_lookup(pivot_nick, session)
                    )
                    if tg_p.get("exists"):
                        p3_tg = f"По нику @{pivot_nick}: {tg_p.get('url')} ({tg_p.get('display_name')})"
                    if isinstance(vk_p, dict) and vk_p.get("found"):
                        p4_vk = f"По нику @{pivot_nick}: {vk_p.get('url')} ({vk_p.get('full_name')})"
                        if p2_name == "Не обнаружено":
                            p2_name = f"{vk_p.get('full_name')} (ВК по нику почты)"
                    p5_tt_yt = f"TikTok: {tt_yt_p['tiktok']} | YouTube: {tt_yt_p['youtube']}"

                    if deep:
                        maigret_p = await self.run_maigret(pivot_nick, full=False)
                        raw_sections.extend([
                            (f"🔗 PIVOTING (@{pivot_nick}): TELEGRAM / ВК / TT / YT", {"tg": tg_p, "vk": vk_p, "tt_yt": tt_yt_p}),
                            (f"🔗 PIVOTING (@{pivot_nick}): MAIGRET", maigret_p)
                        ])

            elif target_type == TargetType.PHONE:
                p_meta = self.phone_lookup(target)
                ig_out = await self.run_ignorant(target)
                p9_geo_net = f"Регион: {p_meta.get('region')} | Оператор: {p_meta.get('carrier')} | Пояс: {', '.join(p_meta.get('timezone', []))}"
                used_ig = [l.strip() for l in ig_out.splitlines() if "[+]" in l]
                p6_platforms = f"Привязка номера: {', '.join(used_ig)}" if used_ig else "Привязок в Ignorant не обнаружено"
                raw_sections.extend([("МЕТАДАННЫЕ НОМЕРА", p_meta), ("IGNORANT", ig_out)])

            elif target_type == TargetType.TG_ID:
                reg = self.estimate_tg_reg_date(int(target))
                vk_id_info = await self.vk_lookup(target, session)
                p3_tg = f"ID: {target} | Оценка даты регистрации в TG: {reg['estimated_registration']}"
                if isinstance(vk_id_info, dict) and vk_id_info.get("found"):
                    p2_name = f"{vk_id_info.get('full_name')} (ВК id{target})"
                    p4_vk = f"{vk_id_info.get('url')} ({vk_id_info.get('full_name')})"
                raw_sections.extend([("TELEGRAM ID АНАЛИЗ", reg), ("ВКОНТАКТЕ ПО ID", vk_id_info)])

            elif target_type == TargetType.FULLNAME:
                p2_name = target
                vk_list = await self.vk_lookup(target, session, by_name=True)
                if isinstance(vk_list, list) and vk_list:
                    top_matches = [f"{u['full_name']} ({u.get('city') or 'н/д'}, ДР: {u.get('bdate') or 'н/д'}) - {u['url']}" for u in vk_list[:3]]
                    p4_vk = " ; ".join(top_matches)
                else:
                    p4_vk = "Для поиска по ФИО в ВК укажите VK_SERVICE_TOKEN в .env"
                raw_sections.append(("ПОИСК ПО ФИО В ВК", vk_list))

            elif target_type in (TargetType.DOMAIN, TargetType.IP):
                if target_type == TargetType.DOMAIN:
                    dns_info = self.dns_and_ip_resolve(target)
                    subs, breaches = await asyncio.gather(
                        self.crtsh_subdomains(target, session),
                        self.deep_breach_intelligence(target, target_type, session)
                    )
                    first_ip = dns_info["A"][0] if dns_info.get("A") else None
                    ip_data = await self.ip_free_lookup(first_ip, session) if first_ip else {}
                    p6_platforms = f"Найдено поддоменов (crt.sh): {len(subs)} ({', '.join(subs[:5])})"
                    p8_stealers = breaches["stealers"]
                    p9_geo_net = f"IP: {first_ip} ({ip_data.get('country')}, {ip_data.get('isp')}) | MX: {', '.join(dns_info.get('MX', [])[:2])}"
                    raw_sections.extend([("DNS", dns_info), ("CRT.SH ПОДДОМЕНЫ", subs), ("IP ДАННЫЕ", ip_data), ("УТЕЧКИ ДОМЕНА", breaches)])
                else:
                    ip_data = await self.ip_free_lookup(target, session)
                    p9_geo_net = f"Страна: {ip_data.get('country')}, Город: {ip_data.get('city')}, Провайдер: {ip_data.get('isp')} (ASN: {ip_data.get('asn')})"
                    raw_sections.append(("IP ДАННЫЕ", ip_data))

        short_10 = "\n".join([
            "📋 ВЫЖИМКА РАЗВЕДКИ (10 ПУНКТОВ)",
            "━━━━━━━━━━━━━━━━━━",
            f"1. 🎯 Объект: {p1_target}",
            f"2. 👤 Имя / ФИО: {p2_name}",
            f"3. 💬 Telegram: {p3_tg}",
            f"4. 🌐 ВКонтакте: {p4_vk}",
            f"5. 🎬 TikTok и YouTube: {p5_tt_yt}",
            f"6. 📱 Сервисы и соцсети: {p6_platforms}",
            f"7. 🚨 Слитые базы (LeakCheck/Xposed): {p7_leaks}",
            f"8. 🦠 Логи инфостилеров: {p8_stealers}",
            f"9. 📡 Гео / Сеть / Оператор: {p9_geo_net}",
            f"10. 🔄 Вторые ники и связи: {p10_aliases}",
        ])

        if not deep:
            return short_10, short_10

        full_blocks = [
            short_10,
            "",
            "==================================================",
            " ПОЛНЫЙ РАЗВЁРНУТЫЙ ОТЧЁТ (DEEP MODE + PIVOTING)",
            "=================================================="
        ]
        for title, data in raw_sections:
            formatted = json.dumps(data, indent=2, ensure_ascii=False) if isinstance(data, (dict, list)) else str(data)
            full_blocks.append(f"\n[ {title} ]\n{'-' * len(title)}\n{formatted}")

        full_text = "\n".join(full_blocks)
        return short_10, full_text
